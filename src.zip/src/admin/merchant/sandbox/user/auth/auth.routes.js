const express = require("express");
const router = express.Router();
const authController = require("./auth.controller");
const authMiddleware = require("../../../../../middlewares/auth.middleware");
const {
  loginLimiter,
} = require("../../../../../middlewares/ratelimit.middleware");

router.post(
  "/login",
  loginLimiter,
  authController.login,
);

router.post(
  "/logout",
  authMiddleware.verifyAccessToken,
  authController.logout,
);

router.post("/register", loginLimiter, authController.register);


router.post(
  "/refresh-token",
  authMiddleware.verifyRefreshToken,
  authController.refreshToken,
);

module.exports = router;